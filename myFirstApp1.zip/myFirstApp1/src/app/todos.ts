export class Todos {
    constructor(public id: number, public title: string, public completed: string) {}
}
