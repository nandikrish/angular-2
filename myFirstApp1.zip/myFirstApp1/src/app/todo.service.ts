import { Injectable, Input } from '@angular/core';
import 'rxjs/Rx';

import { Http, Response } from '@angular/http';
import { Todos } from './todos';


@Injectable()
export class TodoService {
  private todos: Todos[] = [];

  constructor(private http: Http) { }

  getTodos() {
    return this.http.get("https://jsonplaceholder.typicode.com/todos")
      .map((response: Response) => response.json())
  }
}
