export class Users {
    constructor(public name: string, public email: string, public phone: string, public website:string) {}
}
