import { Injectable } from '@angular/core';

import { Http, Response } from '@angular/http';

@Injectable()
export class UserService {

  constructor(private http:Http) {}

  getUsers(){
    return this.http.get("https://jsonplaceholder.typicode.com/users")
    .map((response: Response) => response.json())
  }

}
