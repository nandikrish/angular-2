import { Component } from '@angular/core';

@Component({
  selector: 'fa-root',
  templateUrl: './app.component.html',
})
export class AppComponent {
}
